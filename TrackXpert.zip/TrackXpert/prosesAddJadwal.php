<!-- prosesAddJadwal.php -->
<?php
include "SESSION-Login/koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $jenis = $_POST['jenis'];
    $plat = $_POST['plat'];
    $jadwal_pemeliharaan = $_POST['jadwal_pemeliharaan'];

    // Fetch vehicle id based on jenis and plat
    $queryVehicleId = "SELECT id FROM vehicle WHERE jenis='$jenis' AND plat='$plat'";
    $resultVehicleId = mysqli_query($mysqli, $queryVehicleId);

    if ($resultVehicleId && mysqli_num_rows($resultVehicleId) > 0) {
        $vehicle = mysqli_fetch_assoc($resultVehicleId);
        $vehicle_id = $vehicle['id'];

        if ($_POST['aksi'] == 'add') {
            // Start transaction
            mysqli_begin_transaction($mysqli);

            try {
                // Add jadwal_kendaraan
                $queryAddJadwal = "INSERT INTO jadwal_kendaraan (vehicle_id, jadwal_pemeliharaan) VALUES ('$vehicle_id', '$jadwal_pemeliharaan')";
                if (!mysqli_query($mysqli, $queryAddJadwal)) {
                    throw new Exception("Error adding jadwal: " . mysqli_error($mysqli));
                }

                // Commit transaction
                mysqli_commit($mysqli);
                header('Location: adminManageJadwal.php?status=success');
                exit();
            } catch (Exception $e) {
                // Rollback transaction
                mysqli_rollback($mysqli);
                echo $e->getMessage();
            }
        } else if ($_POST['aksi'] == 'edit') {
            $jadwal_id = $_POST['jadwal_id'];

            // Update jadwal_kendaraan
            $queryUpdateJadwal = "UPDATE jadwal_kendaraan SET vehicle_id = '$vehicle_id', jadwal_pemeliharaan = '$jadwal_pemeliharaan' WHERE jadwal_id = '$jadwal_id'";
            if (!mysqli_query($mysqli, $queryUpdateJadwal)) {
                echo "Error updating jadwal: " . mysqli_error($mysqli);
            }

            header('Location: adminManageJadwal.php?status=edit-success');
            exit();
        }
    } else {
        echo "Vehicle not found.";
    }
}

if (isset($_GET['hapus'])) {
    $jadwal_id = $_GET['hapus'];

    // Start transaction
    mysqli_begin_transaction($mysqli);

    try {
        // Delete jadwal_kendaraan
        $queryDeleteJadwal = "DELETE FROM jadwal_kendaraan WHERE jadwal_id = '$jadwal_id'";
        if (!mysqli_query($mysqli, $queryDeleteJadwal)) {
            throw new Exception("Error deleting jadwal: " . mysqli_error($mysqli));
        }

        // Commit transaction
        mysqli_commit($mysqli);
        header('Location: adminManageJadwal.php?status=delete-success');
        exit();
    } catch (Exception $e) {
        // Rollback transaction
        mysqli_rollback($mysqli);
        echo $e->getMessage();
    }
}

$mysqli->close();
?>
