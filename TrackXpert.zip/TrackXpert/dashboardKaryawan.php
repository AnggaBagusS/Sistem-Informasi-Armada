<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location: loginKaryawan.php');
    exit();
}

$nama = isset($_SESSION['nama']) ? $_SESSION['nama'] : 'User';
$vehicle = isset($_SESSION['vehicle']) ? $_SESSION['vehicle'] : null;
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TrackXpert Dashboard</title>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap");

      body {
        font-family: "Poppins", sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        height: 100vh;
        background-color: #f0f0f0;
        /* overflow-x: hidden; */
      }

      .sidebar {
        width: 240px;
        background-color: #ffffff;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        transition: transform 0.3s ease;
        position: fixed;
        left: 0;
        top: 0;
        bottom: 0;
      }

      .sidebar.hidden {
        transform: translateX(-100%);
      }

      .sidebar .logo {
        padding: 20px;
        text-align: center;
        border-bottom: 1px solid #e0e0e0;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .sidebar .logo img {
        width: 60px;
        margin-bottom: 10px;
      }

      .sidebar .logo span {
        display: block;
        font-weight: bold;
        font-size: 13px;
        color: #333;
      }

      .sidebar .nav-item {
        padding: 15px 25px;
        color: #333;
        text-decoration: none;
        display: flex;
        align-items: center;
        border-bottom: 1px solid #e0e0e0;
        transition: background 0.3s;
      }

      .sidebar .nav-item:hover {
        background-color: #f0f0f0;
      }

      .sidebar .nav-item i {
        margin-right: 10px;
      }

      .sidebar .nav-item.active {
        background-color: rgb(174, 195, 195, 0.6);
        color: black;
      }

      .content {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        transition: margin-left 0.3s ease;
        margin-left: 250px;
        width: calc(100% - 250px);
      }

      .content.expanded {
            margin-left: 0;
            width: 100%;
        }

      .header {
        background-color: #ffffff;
        padding: 10px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #e0e0e0;
      }

      .header .menu-toggle {
        font-size: 15px;
        cursor: pointer;
        font-weight: bold;
        color: rgb(0, 0, 0, 0.4);
      }

      .header .user-info {
        display: flex;
        align-items: center;
      }

      .header .user-info span {
        font-size: 15px;
        margin-right: 10px;
        font-weight: bold;
        color: #333;
      }

      .header .user-info i {
        font-size: 24px;
      }

      .main-content {
        padding: 20px;
        background-color: #ffffff;
        flex-grow: 1;
      }

      .breadcrumb {
        font-size: 14px;
        font-weight: bold;
        margin-bottom: 20px;
      }

      .breadcrumb .breadcrumb-item.active {
        color: #007bff;
      }

      .breadcrumb .breadcrumb-item {
        color: #000;
      }

      .breadcrumb .breadcrumb-item:not(.active) {
        color: #000;
      }

      .dashboard-card {
        background-color: #2bb6ad;
        color: white;
        border-radius: 10px;
        padding: 20px;
        display: flex;
        flex-wrap: wrap;
        flex-direction: column;
        align-items: center;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        width: 95%;
        margin: 20px 0;
        overflow: hidden;
      }

      .dashboard-card .greeting {
        font-size: 18px;
        font-weight: bold;
        text-align: center;
        margin-bottom: 20px;
        margin-top: 0px;
        background-color: rgba(255, 255, 255, 0.3);
        padding: 5px;
        border-radius: 5px;
        width: 100%;
      }

      .dashboard-card .isi {
        display: flex;
        flex-direction: row;
        /* flex-grow: 1; */
        width: 100%;
        justify-content: space-between;
        align-items: center;
        text-align: left;
        gap: 20px;
      }

      .dashboard-card .isi .kiri, .dashboard-card .isi .kanan {
        flex: 1;
    }

      /* .dashboard-card .isi .kiri { 
        /* width: 100%; */
        /* flex-grow: 1;
        text-align: left;
      } */ 

      .dashboard-card .kiri h2 {
        font-size: 25px;
      }
      
      .dashboard-card .kiri p {
        margin: 5px 0;
        font-size: 20px;
      }
      
      .dashboard-card .icon {
        color: rgb(0, 0, 0, 0.3);
        flex-grow: 1;
        display: flex;
        align-items: center;
        font-size: 100px;
        justify-content: center;
        height: 100%;
        width: 100%;
      }
      .dashboard-card .kanan {
        text-align: right;
        flex-grow: 1;
      }

      .dashboard-card .kanan .driver {
        margin-right: 0px;
        text-align: right;
      }

      .dashboard-card .kanan .driver p {
        font-size: 12px;
      }

      .dashboard-card .kanan .status {
        margin-right: 0px;
        display: flex;
        align-items: end;
      }

      .dashboard-card .kanan .status span {
        margin-right: 10px;
        font-weight: bold;
      }

      .dashboard-card .kanan .status span {
        margin-right: 0;
        margin-left: 8px;
        font-weight: bold;
      }

      .dashboard-card .kanan .status .status-label {
        background-color: #28a745;
        padding: 5px 10px;
        border-radius: 5px;
        color: white;
        font-size: 14px;
        max-width: 100%; 
        white-space: nowrap; 
        overflow: hidden; 
        text-overflow: ellipsis;
      }

      .dashboard-card .kanan .status .status-label.normal {
        background-color: #28a745; /* Hijau */
    }

    .dashboard-card .kanan .status .status-label.in-repair {
        background-color: #ffc107; /* Kuning */
    }

    @media (max-width: 768px) {
        .dashboard-card .isi {
            flex-direction: column;
            text-align: center;
        }

        .dashboard-card .kanan {
            text-align: center;
        }

        .dashboard-card .kanan .driver, .dashboard-card .kanan .status {
            text-align: center;
        }
    }

    </style>

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
      integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>
  <body>
    
    <div class="sidebar">
      <div class="logo">
        <img src="gambar/logo.png" alt="TrackXpert Logo" />
        <span>TRACKXPERT</span>
      </div>
      <a href="dashboardKaryawan.php" class="nav-item active">
        <i class="fas fa-home"></i> DASHBOARD
      </a>
      <a href="kendaraanKaryawan.php" class="nav-item"> <i class="fas fa-car"></i> KENDARAAN </a>
      <a href="absenKaryawan.php" class="nav-item">
        <i class="fas fa-calendar-check"></i> ABSENSI
      </a>
      <a href="bahanbakarKaryawan.php" class="nav-item">
        <i class="fas fa-gas-pump"></i> BAHAN BAKAR
      </a>
      <a href="logoutKaryawan.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> LOGOUT
      </a>
    </div>
    <div class="content">
      <div class="header">
        <div class="menu-toggle">
          <p>KARYAWAN</p>
          <i class="fas fa-bars"></i>
        </div>
        <div class="user-info">
          <span><?php echo htmlspecialchars($nama); ?></span>
          <i class="fas fa-user-circle"></i>
        </div>
      </div>
      <div class="main-content">
        <div class="breadcrumb">
          <span class="breadcrumb-item active">DASHBOARD</span>
          <span class="breadcrumb-item">/ OVERVIEW</span>
        </div>

        <div class="dashboard-card">
        <div class="greeting">Selamat Datang di TrackXpert!</div>
        <?php if ($vehicle): ?>
        <div class="isi">
            <div class="kiri">
                <h2><?php echo htmlspecialchars($vehicle['jenis']); ?></h2>
                <hr />
                <p><?php echo htmlspecialchars($vehicle['plat']); ?></p>
            </div>
            <div class="icon">
                <i class="fas fa-car"></i>
            </div>
            <div class="kanan">
                <div class="driver">
                    <p>DRIVER</p>
                    <h3><?php echo htmlspecialchars($nama); ?></h3>
                    <hr />
                </div>
                <div class="status">
                    <span>Status</span>
                      <?php 
                          $status = htmlspecialchars($vehicle['status']);
                          $statusClass = $status == 'In Repair' ? 'in-repair' : 'normal';
                      ?>
                    <span class="status-label <?php echo $statusClass; ?>">
                      <?php echo $status; ?>
                    </span>
                </div>
            </div>
        </div>
        <?php else: ?>
        <p>Tidak ada informasi kendaraan.</p>
        <?php endif; ?>
    </div>
      </div>
    </div>

    <!-- Font Awesome Script -->
    <script
      src="https://kit.fontawesome.com/a076d05399.js"
      crossorigin="anonymous"
    ></script>

    <!-- JavaScript -->
    <script>
        document.querySelector(".menu-toggle i").addEventListener("click", function () {
            document.querySelector(".sidebar").classList.toggle("hidden");
            document.querySelector(".content").classList.toggle("expanded");
        });
    </script>
  </body>
</html>
