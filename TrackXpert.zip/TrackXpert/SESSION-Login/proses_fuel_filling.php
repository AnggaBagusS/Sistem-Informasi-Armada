<?php
session_start();
include "koneksi.php";

// Mendapatkan data dari form
$nama = $_POST['nama'];
$plat = $_POST['plat'];
$jenis = $_POST['jenis'];
$total_biaya = $_POST['total_biaya'];
$tanggal_transaksi = $_POST['tanggal_transaksi'];
$bukti = $_FILES['bukti']['name'];
$tmp_bukti = $_FILES['bukti']['tmp_name'];

// Path untuk menyimpan gambar
$destination_folder = __DIR__ . '/uploads/struk/';
$destination_path = $destination_folder . basename($bukti);

// Pastikan folder tujuan ada
if (!file_exists($destination_folder)) {
    mkdir($destination_folder, 0777, true);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proses Transaksi</title>
    <style>
        /* Styles for the pop-up */
        .popup {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
            justify-content: center;
            align-items: center;
        }
        .popup-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 300px;
            text-align: center;
            border-radius: 10px;
        }
        .popup-content .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .popup-content .close:hover,
        .popup-content .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .popup-content .success-icon {
            font-size: 50px;
            color: green;
        }
    </style>
</head>
<body>
    <div id="popup" class="popup">
        <div class="popup-content">
            <span class="close" onclick="closePopup()">&times;</span>
            <div class="success-icon">&#10004;</div>
            <h2>Sukses</h2>
            <p>Data berhasil disimpan</p>
            <button onclick="closePopup()">OK</button>
        </div>
    </div>

    <script>
        function showPopup() {
            document.getElementById("popup").style.display = "flex";
        }

        function closePopup() {
            document.getElementById("popup").style.display = "none";
            window.location.href = "/TrackXpert/dashboardKaryawan.php";
        }
    </script>

<?php
// Memindahkan file gambar ke folder tujuan
if (move_uploaded_file($tmp_bukti, $destination_path)) {
    // Mendapatkan driver_id berdasarkan nama driver
    $sql_driver = mysqli_query($mysqli, "SELECT driver_id FROM driver WHERE nama='$nama'");
    if (!$sql_driver) {
        die("Error: " . mysqli_error($mysqli));
    }
    $driver = mysqli_fetch_assoc($sql_driver);
    $driver_id = $driver['driver_id'];

    // Mendapatkan vehicle_id berdasarkan driver_id, jenis, dan plat
    $sql_vehicle = mysqli_query($mysqli, "SELECT id FROM vehicle WHERE driver_id='$driver_id' AND jenis='$jenis' AND plat='$plat'");
    if (!$sql_vehicle) {
        die("Error: " . mysqli_error($mysqli));
    }
    $vehicle = mysqli_fetch_assoc($sql_vehicle);
    $vehicle_id = $vehicle['id'];

    // Menyimpan data pengisian bahan bakar ke tabel fuel_filling
    $sql_insert = "INSERT INTO fuel_filling (driver_id, vehicle_id, total_biaya, tanggal_transaksi, bukti_struk) VALUES ('$driver_id', '$vehicle_id', '$total_biaya', '$tanggal_transaksi', '$bukti')";

    if (mysqli_query($mysqli, $sql_insert)) {
        echo "<script>showPopup();</script>";
    } else {
        echo "Error: " . $sql_insert . "<br>" . mysqli_error($mysqli);
    }
} else {
    echo "Error uploading file.";
}

mysqli_close($mysqli);
?>
</body>
</html>
