<?php
include "SESSION-Login/koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = $_POST['password'];


    if ($_POST['aksi'] == 'add') {
        // Mulai Transaksi
        mysqli_begin_transaction($mysqli);

        try {
            // Tambah login
            $queryAddLogin = "INSERT INTO login (username, password) VALUES ('$username', '$password')";
            if (!mysqli_query($mysqli, $queryAddLogin)) {
                throw new Exception("Error adding login: " . mysqli_error($mysqli));
            }
            $login_id = mysqli_insert_id($mysqli);

            // Tambah driver dengan foreign key 'id'
            $queryAddDriver = "INSERT INTO driver (id, nama) VALUES ('$login_id', '$nama')";
            if (!mysqli_query($mysqli, $queryAddDriver)) {
                throw new Exception("Error adding driver: " . mysqli_error($mysqli));
            }

            // Commit Transaksi
            mysqli_commit($mysqli);
            header('Location: adminManageKaryawan.php?status=success');
            exit();
        } catch (Exception $e) {
            // Rollback Transaksi
            mysqli_rollback($mysqli);
            echo $e->getMessage();
        }
    } else if ($_POST['aksi'] == 'edit') {
        $id_login = $_POST['id_login'];

        // Update driver
        $queryUpdateDriver = "UPDATE driver SET nama = '$nama', vehicle_id = '$vehicle_id' WHERE id = '$id_login'";
        if (!mysqli_query($mysqli, $queryUpdateDriver)) {
            echo "Error updating driver: " . mysqli_error($mysqli);
        }

        // Update login
        $queryUpdateLogin = "UPDATE login SET username = '$username', password = '$password' WHERE id = '$id_login'";
        if (!mysqli_query($mysqli, $queryUpdateLogin)) {
            echo "Error updating login: " . mysqli_error($mysqli);
        }

        header('Location: adminManageKaryawan.php?status=edit-success');
        exit();
    }
}

if (isset($_GET['hapus'])) {
    $id_login = $_GET['hapus'];

    // Mulai Transaksi
    mysqli_begin_transaction($mysqli);

    try {
        // Hapus driver
        $queryDeleteDriver = "DELETE FROM driver WHERE id = '$id_login'";
        if (!mysqli_query($mysqli, $queryDeleteDriver)) {
            throw new Exception("Error deleting driver: " . mysqli_error($mysqli));
        }

        // Hapus login
        $queryDeleteLogin = "DELETE FROM login WHERE id = '$id_login'";
        if (!mysqli_query($mysqli, $queryDeleteLogin)) {
            throw new Exception("Error deleting login: " . mysqli_error($mysqli));
        }

        // Commit Transaksi
        mysqli_commit($mysqli);
        header('Location: adminManageKaryawan.php?status=delete-success');
        exit();
    } catch (Exception $e) {
        // Rollback Transaksi
        mysqli_rollback($mysqli);
        echo $e->getMessage();
    }
}

$mysqli->close();
?>
