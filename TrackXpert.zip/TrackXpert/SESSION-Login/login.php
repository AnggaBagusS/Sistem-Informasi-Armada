<?php
session_start();
include "koneksi.php";

$username = $_POST['username'];
$password = $_POST['password'];

// Mengecek kondisi jika user ada atau tidak
$sql_user = mysqli_query($mysqli, "SELECT * FROM login WHERE username='$username' AND password='$password'");
$cek_user = mysqli_num_rows($sql_user);

if ($cek_user > 0) {
    $user = mysqli_fetch_assoc($sql_user);
    $id = $user['id'];

    // Mengambil nama driver dari tabel driver
    $sql_driver = mysqli_query($mysqli, "SELECT * FROM driver WHERE id='$id'");
    $driver = mysqli_fetch_assoc($sql_driver);
    $driver_id = $driver['driver_id'];

    //Mengambil informasi kendaraan dari tabel vehicle
    $sql_vehicle = mysqli_query($mysqli, "SELECT * FROM vehicle WHERE driver_id='$driver_id'");
    $vehicle = mysqli_fetch_assoc($sql_vehicle);

    //Mengambil path gambar kendaraan dari tabel vehicle_image
    $vehicle_id = $vehicle['id'];
    $sql_image = mysqli_query($mysqli, "SELECT * FROM vehicle_image WHERE vehicle_id='$vehicle_id'");
    $image = mysqli_fetch_assoc($sql_image);
    $image_path = $image['image_path'];

    $_SESSION['login'] = true;
    $_SESSION['nama'] = $driver['nama']; // Menyimpan nama driver ke dalam sesi
    $_SESSION['vehicle'] = $vehicle;
    $_SESSION['image_path'] = $image_path;

    header('Location: ../dashboardKaryawan.php');
    exit();
}  else {
    header('Location: ../loginKaryawan.php?error=1');
    exit();
}
?>