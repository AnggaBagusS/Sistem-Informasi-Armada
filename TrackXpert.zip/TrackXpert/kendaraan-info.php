<?php
// Data kendaraan (ini seharusnya berasal dari database pada kenyataannya)
$vehicle = [
    'nomor_polisi' => 'BE 1707 AH',
    'merk_tipe' => 'Toyota Limo 2016',
    'pengemudi' => 'Ujang',
    'status' => 'Aktif',
    'kerusakan' => 'Tidak Ada',
    'gambar' => 'https://example.com/toyota-limo.jpg' // Ubah URL gambar sesuai dengan gambar yang ada
];
?>

<div class="vehicle-info">
    <h3>Informasi Kendaraan</h3>
    <table>
        <tr>
            <th>Nomor Polisi</th>
            <td><?php echo $vehicle['nomor_polisi']; ?></td>
        </tr>
        <tr>
            <th>Merk/Tipe</th>
            <td><?php echo $vehicle['merk_tipe']; ?></td>
        </tr>
        <tr>
            <th>Pengemudi</th>
            <td><?php echo $vehicle['pengemudi']; ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?php echo $vehicle['status']; ?></td>
        </tr>
        <tr>
            <th>Kerusakan</th>
            <td><?php echo $vehicle['kerusakan']; ?></td>
        </tr>
    </table>
    <img src="<?php echo $vehicle['gambar']; ?>" alt="Gambar Kendaraan">
</div>
