<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location: loginKaryawan.php');
    exit();
}

$nama = isset($_SESSION['nama']) ? $_SESSION['nama'] : 'USER';
$vehicle = isset($_SESSION['vehicle']) ? $_SESSION['vehicle'] : '';
$image_path = isset($_SESSION['image_path']) ? $_SESSION['image_path'] : 'gambar/mobil1.png'; // Path gambar default atau placeholder
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Logout Karyawan</title>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap");

      body {
        font-family: "Poppins", sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        height: 100vh;
        background-color: #f0f0f0;
        /* overflow-x: hidden; */
      }

      .sidebar {
        width: 240px;
        background-color: #ffffff;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        transition: transform 0.3s ease;
        position: fixed;
        left: 0;
        top: 0;
        bottom: 0;
      }

      .sidebar.hidden {
        transform: translateX(-100%);
      }

      .sidebar .logo {
        padding: 20px;
        text-align: center;
        border-bottom: 1px solid #e0e0e0;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .sidebar .logo img {
        width: 60px;
        margin-bottom: 10px;
      }

      .sidebar .logo span {
        display: block;
        font-weight: bold;
        font-size: 13px;
        color: #333;
      }

      .sidebar .nav-item {
        padding: 15px 25px;
        color: #333;
        text-decoration: none;
        display: flex;
        align-items: center;
        border-bottom: 1px solid #e0e0e0;
        transition: background 0.3s;
      }

      .sidebar .nav-item:hover {
        background-color: #f0f0f0;
      }

      .sidebar .nav-item i {
        margin-right: 10px;
      }

      .sidebar .nav-item.active {
        background-color: rgb(174, 195, 195, 0.6);
        color: black;
      }

      .content {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        transition: margin-left 0.3s ease;
        margin-left: 250px;
        width: calc(100% - 250px);
      }

      .content.expanded {
        margin-left: 0;
        width: 100%;
      }

      .header {
        background-color: #ffffff;
        padding: 10px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #e0e0e0;
      }

      .header .menu-toggle {
        font-size: 15px;
        cursor: pointer;
        font-weight: bold;
        color: rgb(0, 0, 0, 0.4);
      }

      .header .user-info {
        display: flex;
        align-items: center;
      }

      .header .user-info span {
        font-size: 15px;
        margin-right: 10px;
        font-weight: bold;
        color: #333;
      }

      .header .user-info i {
        font-size: 24px;
      }

      .main-content {
        padding: 20px;
        background-color: #ffffff;
        flex-grow: 1;
      }

      .breadcrumb {
        font-size: 14px;
        font-weight: bold;
        margin-bottom: 20px;
      }

      .breadcrumb .breadcrumb-item.active {
        color: #007bff;
      }

      .breadcrumb .breadcrumb-item {
        color: #000;
      }

      .breadcrumb .breadcrumb-item:not(.active) {
        color: #000;
      }

      .modal {
        display: none; /* Awalnya modal tersembunyi */
        position: fixed;
        z-index: 1; /* Memastikan modal di atas elemen lainnya */
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto; /* Jika konten modal lebih besar dari layar */
        background-color: rgba(
          0,
          0,
          0,
          0.4
        ); /* Latar belakang hitam transparan */
        align-items: center; /* Pusatkan secara vertikal */
        justify-content: center; /* Pusatkan secara horizontal */
      }

      .modal-content {
        background-color: #fefefe;
        padding: 20px;
        border: 1px solid #888;
        width: 80%; /* Lebar modal */
        max-width: 400px; /* Maksimal lebar modal */
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        text-align: center; /* Mengatur teks di tengah */
      }

      .modal-buttons {
        display: flex;
        justify-content: space-around;
        margin-top: 20px;
      }

      .cancel-button,
      .confirm-button {
        padding: 10px 20px;
        border: none;
        cursor: pointer;
      }

      .cancel-button {
        background-color: #f44336; /* Warna merah untuk tombol batal */
        color: white;
      }

      .confirm-button {
        background-color: #4caf50; /* Warna hijau untuk tombol konfirmasi */
        color: white;
      }

      .modal-icon {
        font-size: 40px;
        margin-bottom: 10px;
      }
    </style>

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
      integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>
  <body>
    <div class="sidebar">
      <div class="logo">
        <img src="gambar/logo.png" alt="TrackXpert Logo" />
        <span>TRACKXPERT</span>
      </div>
      <a href="dashboardKaryawan.php" class="nav-item">
        <i class="fas fa-home"></i> DASHBOARD
      </a>
      <a href="kendaraanKaryawan.php" class="nav-item">
        <i class="fas fa-car"></i> KENDARAAN
      </a>
      <a href="absenKaryawan.php" class="nav-item">
        <i class="fas fa-calendar-check"></i> ABSENSI
      </a>
      <a href="bahanBakarKaryawan.php" class="nav-item">
        <i class="fas fa-gas-pump"></i> BAHAN BAKAR
      </a>
      <a href="#" id="logout-button" class="nav-item active">
        <i class="fas fa-sign-out-alt"></i> LOGOUT
      </a>
    </div>
    <div class="content">
      <div class="header">
        <div class="menu-toggle">
          <p>KARYAWAN</p>
          <i class="fas fa-bars"></i>
        </div>
        <div class="user-info">
          <span><?php echo htmlspecialchars($nama); ?></span>
          <i class="fas fa-user-circle"></i>
        </div>
      </div>
      <div class="main-content">
        <div class="breadcrumb">
          <span class="breadcrumb-item active">DASHBOARD</span>
          <span class="breadcrumb-item">/ LOGOUT</span>
        </div>
      </div>
    </div>

    <!-- Bagian modal di dalam HTML -->
    <div id="logout-modal" class="modal">
      <div class="modal-content">
        <div class="modal-icon">
          <i class="fas fa-exclamation-circle"></i>
        </div>
        <h3>Konfirmasi Logout</h3>
        <p>Apakah Anda yakin ingin logout?</p>
        <div class="modal-buttons">
          <button 
            class="cancel-button"
            onclick="location.href='dashboardKaryawan.php'">Batal</button>
          <button
            class="confirm-button"
            onclick="location.href='prosesLogout.php'">Logout
          </button>
        </div>
      </div>
    </div>

    <script>
      document.addEventListener("DOMContentLoaded", function () {
        const sidebar = document.querySelector(".sidebar");
        const menuToggle = document.querySelector(".menu-toggle");
        const content = document.querySelector(".content");
        const logoutButton = document.querySelector("#logout-button");
        const logoutModal = document.querySelector("#logout-modal");
        const cancelButton = document.querySelector(".cancel-button");

        console.log("DOM content loaded");

        // Tombol untuk menampilkan sidebar (bila layar kecil)
        menuToggle.addEventListener("click", function () {
          sidebar.classList.toggle("hidden");
          content.classList.toggle("expanded");
          console.log("Menu toggled");
        });

        // Tombol logout untuk menampilkan modal
        logoutButton.addEventListener("click", function (e) {
          e.preventDefault(); // Menghindari redirect
          console.log("Logout button clicked");
          logoutModal.style.display = "flex";
        });

        // Tombol batal pada modal
        cancelButton.addEventListener("click", function () {
          console.log("Cancel button clicked");
          logoutModal.style.display = "none";
        });
      });
    </script>
  </body>
</html>
