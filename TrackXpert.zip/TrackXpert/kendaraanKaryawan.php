<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location: loginKaryawan.php');
    exit();
}

$nama = isset( $_SESSION['nama']) ? $_SESSION['nama'] : 'USER';
$vehicle = isset($_SESSION['vehicle']) ? $_SESSION['vehicle'] : '';
$image_path = isset($_SESSION['image_path']) ? 'gambar/' . $_SESSION['image_path'] : 'gambar/mobil1.png';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TrackXpert Dashboard</title>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap");

      body {
        font-family: "Poppins", sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        height: 100vh;
        background-color: #f0f0f0;
        /* overflow-x: hidden; */
      }

      .sidebar {
        width: 240px;
        background-color: #ffffff;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        transition: transform 0.3s ease;
        position: fixed;
        left: 0;
        top: 0;
        bottom: 0;
      }

      .sidebar.hidden {
        transform: translateX(-100%);
      }

      .sidebar .logo {
        padding: 20px;
        text-align: center;
        border-bottom: 1px solid #e0e0e0;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .sidebar .logo img {
        width: 60px;
        margin-bottom: 10px;
      }

      .sidebar .logo span {
        display: block;
        font-weight: bold;
        font-size: 13px;
        color: #333;
      }

      .sidebar .nav-item {
        padding: 15px 25px;
        color: #333;
        text-decoration: none;
        display: flex;
        align-items: center;
        border-bottom: 1px solid #e0e0e0;
        transition: background 0.3s;
      }

      .sidebar .nav-item:hover {
        background-color: #f0f0f0;
      }

      .sidebar .nav-item i {
        margin-right: 10px;
      }

      .sidebar .nav-item.active {
        background-color: rgb(174, 195, 195, 0.6);
        color: black;
      }

      .content {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        transition: margin-left 0.3s ease;
        margin-left: 250px;
        width: calc(100% - 250px);
      }

      .content.expanded {
        margin-left: 0;
        width: 100%;
      }

      .header {
        background-color: #ffffff;
        padding: 10px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #e0e0e0;
      }

      .header .menu-toggle {
        font-size: 15px;
        cursor: pointer;
        font-weight: bold;
        color: rgb(0, 0, 0, 0.4);
      }

      .header .user-info {
        display: flex;
        align-items: center;
      }

      .header .user-info span {
        font-size: 15px;
        margin-right: 10px;
        font-weight: bold;
        color: #333;
      }

      .header .user-info i {
        font-size: 24px;
      }

      .main-content {
        padding: 20px;
        background-color: #ffffff;
        flex-grow: 1;
      }

      .breadcrumb {
        font-size: 14px;
        font-weight: bold;
        margin-bottom: 20px;
      }

      .breadcrumb .breadcrumb-item.active {
        color: #007bff;
      }

      .breadcrumb .breadcrumb-item {
        color: #000;
      }

      .breadcrumb .breadcrumb-item:not(.active) {
        color: #000;
      }

      /* .vehicle-info {
        text-align: center;
      } */

      .vehicle-info-header {
        font-size: 16px;
        font-weight: bold;
        text-align: center;
        border-radius: 10px;
        width: 100%;
        background-color: #2bb6ad;
        color: white;
        margin-bottom: 15px;
      }

      .vehicle-info-header h3 {
        padding: 5px;
        text-justify: center;
      }

      .vehicle-info-content {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-between;
        width: 100%;
      }

      .vehicle-info-content-text {
        display:flex;
        flex-direction: column;
        flex-grow: 1;
        flex-basis:200px;
        margin-right: 90px;
      }

      .info-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
      }

      .info-item span {
        font-size: 14px;
        background-color: #ccc;
        border-radius: 5px;
        padding: 5px;
        text-align: left; 
      }

      .vehicle-info-content-image {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-grow:1;
        flex-basis: 200px;
        margin-right:0;
      }

      .vehicle-info-content-image img {
        width: 100%;
        max-width: 400px;
        height: auto;
        border-radius: 10px;
        border: 2px solid black;
      }
    </style>

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
      integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>
  <body>
    <div class="sidebar">
      <div class="logo">
        <img src="gambar/logo.png" alt="TrackXpert Logo" />
        <span>TRACKXPERT</span>
      </div>
      <a href="dashboardKaryawan.php" class="nav-item">
        <i class="fas fa-home"></i> DASHBOARD
      </a>
      <a href="kendaraanKaryawan.php" class="nav-item active">
        <i class="fas fa-car"></i> KENDARAAN
      </a>
      <a href="absenKaryawan.php" class="nav-item">
        <i class="fas fa-calendar-check"></i> ABSENSI
      </a>
      <a href="bahanbakarKaryawan.php" class="nav-item">
        <i class="fas fa-gas-pump"></i> BAHAN BAKAR
      </a>
      <a href="logoutKaryawan.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> LOGOUT
      </a>
    </div>
    <div class="content">
      <div class="header">
        <div class="menu-toggle">
          <p>KARYAWAN</p>
          <i class="fas fa-bars"></i>
        </div>
        <div class="user-info">
          <span><?php echo htmlspecialchars($nama); ?></span>
          <i class="fas fa-user-circle"></i>
        </div>
      </div>
      <div class="main-content">
        <div class="breadcrumb">
          <span class="breadcrumb-item active">DASHBOARD</span>
          <span class="breadcrumb-item">/ KENDARAAN</span>
        </div>
        <div class="vehicle-info">
          <div class="vehicle-info-header">
            <h3>Informasi Kendaraan</h3>
          </div>
          <div class="vehicle-info-content">
            <div class="vehicle-info-content-text">
              <div class="info-item">
                <label>Nomor Polisi:</label>
                <span><?php echo htmlspecialchars($vehicle['plat']); ?></span>
              </div>
              <div class="info-item">
                <label>Merk/Tipe:</label>
                <span><?php echo htmlspecialchars($vehicle['jenis']); ?></span>
              </div>
              <div class="info-item">
                <label>Pengemudi:</label>
                <span><?php echo htmlspecialchars($nama); ?></span>
              </div>
              <div class="info-item">
                <label>Status:</label>
                <span><?php echo htmlspecialchars($vehicle['status']); ?></span>
              </div>
              <div class="info-item">
                <label>Kerusakan:</label>
                <span
                  ><?php echo empty($vehicle['kerusakan']) ? 'Tidak Ada' : htmlspecialchars($vehicle['kerusakan']); ?></span
                >
              </div>
            </div>
            <div class="vehicle-info-content-image">
            <img src="<?php echo htmlspecialchars($image_path); ?>" alt="Foto Kendaraan" />
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Font Awesome Script -->
    <script
      src="https://kit.fontawesome.com/a076d05399.js"
      crossorigin="anonymous"
    ></script>

    <!-- JavaScript -->
    <script>
      document
        .querySelector(".menu-toggle i")
        .addEventListener("click", function () {
          document.querySelector(".sidebar").classList.toggle("hidden");
          document.querySelector(".content").classList.toggle("expanded");
        });
    </script>
  </body>
</html>
