<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location: loginKaryawan.php');
    exit();
}


$nama = isset( $_SESSION['nama']) ? $_SESSION['nama'] : 'USER';
$vehicle = isset($_SESSION['vehicle']) ? $_SESSION['vehicle'] : '';
$image_path = isset($_SESSION['image_path']) ? $_SESSION['image_path'] : 'gambar/mobil1.png'; // Path gambar default atau placeholder
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TrackXpert Dashboard</title>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap");

      body {
        font-family: "Poppins", sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        height: 100vh;
        background-color: #f0f0f0;
        /* overflow-x: hidden; */
      }

      .sidebar {
        width: 240px;
        background-color: #ffffff;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        transition: transform 0.3s ease;
        position: fixed;
        left: 0;
        top: 0;
        bottom: 0;
      }

      .sidebar.hidden {
        transform: translateX(-100%);
      }

      .sidebar .logo {
        padding: 20px;
        text-align: center;
        border-bottom: 1px solid #e0e0e0;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .sidebar .logo img {
        width: 60px;
        margin-bottom: 10px;
      }

      .sidebar .logo span {
        display: block;
        font-weight: bold;
        font-size: 13px;
        color: #333;
      }

      .sidebar .nav-item {
        padding: 15px 25px;
        color: #333;
        text-decoration: none;
        display: flex;
        align-items: center;
        border-bottom: 1px solid #e0e0e0;
        transition: background 0.3s;
      }

      .sidebar .nav-item:hover {
        background-color: #f0f0f0;
      }

      .sidebar .nav-item i {
        margin-right: 10px;
      }

      .sidebar .nav-item.active {
        background-color: rgb(174, 195, 195, 0.6);
        color: black;
      }

      .content {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        transition: margin-left 0.3s ease;
        margin-left: 250px;
        width: calc(100% - 250px);
      }

      .content.expanded {
        margin-left: 0;
        width: 100%;
      }

      .header {
        background-color: #ffffff;
        padding: 10px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #e0e0e0;
      }

      .header .menu-toggle {
        font-size: 15px;
        cursor: pointer;
        font-weight: bold;
        color: rgb(0, 0, 0, 0.4);
      }

      .header .user-info {
        display: flex;
        align-items: center;
      }

      .header .user-info span {
        font-size: 15px;
        margin-right: 10px;
        font-weight: bold;
        color: #333;
      }

      .header .user-info i {
        font-size: 24px;
      }

      .main-content {
        padding: 20px;
        background-color: #ffffff;
        flex-grow: 1;
      }

      .breadcrumb {
        font-size: 14px;
        font-weight: bold;
        margin-bottom: 20px;
      }

      .breadcrumb .breadcrumb-item.active {
        color: #007bff;
      }

      .breadcrumb .breadcrumb-item {
        color: #000;
      }

      .breadcrumb .breadcrumb-item:not(.active) {
        color: #000;
      }


      .fuel_filling-header {
        font-size: 16px;
        font-weight: bold;
        text-align: center;
        border-radius: 10px;
        width: 100%;
        background-color: #2bb6ad;
        color: white;
        margin-bottom: 15px;
      }

      .fuel_filling-header h3 {
        padding: 5px;
        text-justify: center;
      }

      .fuel_filling-form {
        background-color: white;
        padding: 10px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        max-width: 800px;
        margin: 0 auto;
        /* justify-content: center; */
      }

      .fuel_filling-form form {
        display: flex;
        flex-direction: column;
      }

.fuel_filling-form label {
    margin: 10px 0 5px;
    font-weight: bold;
    width:300px;
}

.fuel_filling-form input[type="text"],
.fuel_filling-form input[type="date"],
.fuel_filling-form input[type="number"],
.fuel_filling-form input[type="time"],
.fuel_filling-form input[type="file"] {
    padding: 10px;
    margin-bottom: 15px;
    margin-right: 100px;
    margin-left: 0px;
    border: 2px solid rgba(0, 0, 0, 0.2);
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 12px;
    width: 100%;
    box-sizing: border-box;
}

.fuel_filling-form .input-driver, 
.fuel_filling-form .input-plat,
.fuel_filling-form .input-jenis,
.fuel_filling-form .input-total,
.fuel_filling-form .input-tanggal,
.fuel_filling-form .input-bukti {
  display: flex;
  flex-direction: row;

}

.fuel_filling-form .tombol-simpan {
    display: flex;
    justify-content: center;
    margin-top: 20px;
}


.fuel_filling-form input[type="submit"] {
    background-color: #009688;
    color: white;
    border: none;
    cursor: pointer;
    padding: 10px;
    border-radius: 16px;
    border: 2px solid rgba(0, 0, 0, 0.2);
    font-size: 16px;
    width:150px;
    text-align:center;
}

.fuel_filling-form input[type="submit"]:hover {
    background-color: #00796b;
}

      
    </style>

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
      integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>
  <body>
    <div class="sidebar">
      <div class="logo">
        <img src="gambar/logo.png" alt="TrackXpert Logo" />
        <span>TRACKXPERT</span>
      </div>
      <a href="dashboardKaryawan.php" class="nav-item">
        <i class="fas fa-home"></i> DASHBOARD
      </a>
      <a href="kendaraanKaryawan.php" class="nav-item">
        <i class="fas fa-car"></i> KENDARAAN
      </a>
      <a href="absenKaryawan.php" class="nav-item">
        <i class="fas fa-calendar-check"></i> ABSENSI
      </a>
      <a href="bahanBakarKaryawan.php" class="nav-item active">
        <i class="fas fa-gas-pump"></i> BAHAN BAKAR
      </a>
      <a href="logoutKaryawan.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> LOGOUT
      </a>
    </div>
    <div class="content">
      <div class="header">
        <div class="menu-toggle">
          <p>KARYAWAN</p>
          <i class="fas fa-bars"></i>
        </div>
        <div class="user-info">
          <span><?php echo htmlspecialchars($nama); ?></span>
          <i class="fas fa-user-circle"></i>
        </div>
      </div>
      <div class="main-content">
        <div class="breadcrumb">
          <span class="breadcrumb-item active">DASHBOARD</span>
          <span class="breadcrumb-item">/ BAHAN BAKAR</span>
        </div>
        <div class="fuel_filling">
          <div class="fuel_filling-header">
            <h3>Pengisian Bahan Bakar</h3>
          </div>
          <div class="fuel_filling-form">
          <form action="SESSION-Login/proses_fuel_filling.php" method="post" enctype="multipart/form-data">

          <div class="input-driver">
                    <label for="nama">Nama Driver:</label>
                    <input type="text" id="nama" name="nama" value="<?php echo htmlspecialchars($nama); ?>" readonly><br>
          </div>

          <div class="input-plat">
                    <label for="plat">Nomor Polisi:</label>
                    <input type="text" id="plat" name="plat" value="<?php echo htmlspecialchars($vehicle['plat']); ?>" readonly><br>
          </div>

          <div class="input-jenis">
                    <label for="jenis">Jenis Mobil:</label>
                    <input type="text" id="jenis" name="jenis" value="<?php echo htmlspecialchars($vehicle['jenis']); ?>" readonly><br>
          </div>

          <div class="input-total">
                    <label for="total_biaya">Total Biaya Pengisian:</label>
                    <input type="number" name="total_biaya" id="total_biaya" step="0.01" required><br>
          </div>

          <div class="input-tanggal">
                    <label for="tanggal_transaksi">Tanggal Transaksi:</label>
                    <input type="date" id="tanggal_transaksi" name="tanggal_transaksi" required><br>
          </div>

          <div class="input-bukti">
                    <label for="bukti">Bukti Transaksi:</label>
                    <input type="file" name="bukti" id="bukti" required><br>
          </div>

          <div class="tombol-simpan">
                    <input type="submit" value="Simpan">
          </div>
                </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Font Awesome Script -->
    <script
      src="https://kit.fontawesome.com/a076d05399.js"
      crossorigin="anonymous"
    ></script>

    <!-- JavaScript -->
    <script>
      document
        .querySelector(".menu-toggle i")
        .addEventListener("click", function () {
          document.querySelector(".sidebar").classList.toggle("hidden");
          document.querySelector(".content").classList.toggle("expanded");
        });
    </script>
  </body>
</html>
