<?php
include "SESSION-Login/koneksi.php";

if (isset($_POST['aksi'])) {
    $aksi = $_POST['aksi'];
    $mobil = $_POST['mobil'];
    $plat = $_POST['plat'];
    $status = $_POST['status'];
    $kerusakan = $_POST['kerusakan'];
    $dir = "gambar/";

    if ($aksi == "add") {
        $image = $_FILES['image']['name'];
        $tmpFile = $_FILES['image']['tmp_name'];
        move_uploaded_file($tmpFile, $dir . $image);

        // Insert data ke tabel vehicle
        $query_vehicle = "INSERT INTO vehicle (jenis, plat, status, kerusakan) VALUES ('$mobil', '$plat', '$status', '$kerusakan')";
        if (mysqli_query($mysqli, $query_vehicle)) {
            $vehicle_id = mysqli_insert_id($mysqli);
            $query_image = "INSERT INTO vehicle_image (vehicle_id, image_path) VALUES ('$vehicle_id', '$image')";
            if (mysqli_query($mysqli, $query_image)) {
                header('Location: adminManageVehicle.php?status=success');
                exit();
            } else {
                echo "Error: " . mysqli_error($mysqli);
            }
        } else {
            echo "Error: " . mysqli_error($mysqli);
        }
    } else if ($aksi == "edit") {
        $id_vehicle = $_POST['id_vehicle'];
        $query_update_vehicle = "UPDATE vehicle SET jenis='$mobil', plat='$plat', status='$status', kerusakan='$kerusakan' WHERE id='$id_vehicle'";
        if (mysqli_query($mysqli, $query_update_vehicle)) {
            if ($_FILES['image']['name']) {
                // Handle new image upload
                $image = $_FILES['image']['name'];
                $tmpFile = $_FILES['image']['tmp_name'];
                move_uploaded_file($tmpFile, $dir . $image);

                // Get old image path
                $query_old_image = "SELECT image_path FROM vehicle_image WHERE vehicle_id = '$id_vehicle'";
                $result_old_image = mysqli_query($mysqli, $query_old_image);
                if ($result_old_image && mysqli_num_rows($result_old_image) > 0) {
                    $row = mysqli_fetch_assoc($result_old_image);
                    $old_image_path = $row['image_path'];
                    if (file_exists($dir . $old_image_path)) {
                        unlink($dir . $old_image_path);
                    }
                }

                // Update new image path
                $query_update_image = "UPDATE vehicle_image SET image_path='$image' WHERE vehicle_id='$id_vehicle'";
                if (!mysqli_query($mysqli, $query_update_image)) {
                    echo "Error updating image: " . mysqli_error($mysqli);
                }
            }
            header('Location: adminManageVehicle.php?status=edit-success');
            exit();
        } else {
            echo "Error: " . mysqli_error($mysqli);
        }
    }
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    $query_select_image = "SELECT image_path FROM vehicle_image WHERE vehicle_id = '$id'";
    $result_select_image = mysqli_query($mysqli, $query_select_image);
    if ($result_select_image && mysqli_num_rows($result_select_image) > 0) {
        $row = mysqli_fetch_assoc($result_select_image);
        $image_path = $row['image_path'];
        if (file_exists("gambar/" . $image_path)) {
            unlink("gambar/" . $image_path);
        }

        $query_delete_image = "DELETE FROM vehicle_image WHERE vehicle_id = '$id'";
        if (mysqli_query($mysqli, $query_delete_image)) {
            $query_delete_vehicle = "DELETE FROM vehicle WHERE id = '$id'";
            if (mysqli_query($mysqli, $query_delete_vehicle)) {
                header('Location: adminManageVehicle.php?status=delete-success');
                exit();
            } else {
                echo "Error: " . mysqli_error($mysqli);
            }
        } else {
            echo "Error: " . mysqli_error($mysqli);
        }
    } else {
        echo "Data tidak ditemukan atau ada kesalahan dalam pengambilan data gambar.";
    }
}

mysqli_close($mysqli);
?>
