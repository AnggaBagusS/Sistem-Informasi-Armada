<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location: loginAdmin.php');
    exit();
}

include "SESSION-Login/koneksi.php";

// Query Update
if (isset($_GET["ubah"])) {
    $fuel_filling_id = $_GET['ubah'];
    $queryUpdate = "SELECT * FROM fuel_filling WHERE id = '$fuel_filling_id';";
    $sqlUpdate = mysqli_query($mysqli, $queryUpdate);
}

// Query Jadwal
$query = "SELECT fuel_filling.id AS fuel_filling_id, driver.nama, vehicle.plat, vehicle.jenis, fuel_filling.total_biaya, fuel_filling.tanggal_transaksi, fuel_filling.bukti_struk
          FROM fuel_filling
          JOIN vehicle ON fuel_filling.vehicle_id = vehicle.id
          JOIN driver ON fuel_filling.driver_id = driver.driver_id";
$sql = mysqli_query($mysqli, $query);
$no = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <link rel="stylesheet" href="css/dataTables.bootstrap5.min.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/style2.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.min.css">
    <title>TrackXpert</title>
    <script>
        function confirmLogout() {
            Swal.fire({
                title: 'Apakah Anda yakin ingin keluar?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, keluar!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        }

        function confirmDelete(url) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data ini tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = url;
                }
            });
        }
    </script>
</head>
<body>
    <!-- top navigation bar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #2bb6ad;">
      <div class="container-fluid">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="offcanvas"
          data-bs-target="#sidebar"
          aria-controls="offcanvasExample"
        >
          <span class="navbar-toggler-icon" data-bs-target="#sidebar"></span>
        </button>
        <img src="gambar/logo.png" alt="TrackXpert Logo" width="50px"/>
        <a
          class="navbar-brand me-auto ms-lg-0 ms-3 text-uppercase fw-bold"
          href="#"
          >TrackXpert</a
        >
        
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#topNavBar"
          aria-controls="topNavBar"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="topNavBar">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item dropdown">
              <a
                class="nav-link dropdown-toggle ms-2"
                href="#"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <i class="bi bi-person-fill"></i>
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="logout.php" onclick="event.preventDefault(); confirmLogout();">Logout</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- top navigation bar -->
    <!-- offcanvas -->
    <div
      class="offcanvas offcanvas-start sidebar-nav bg-light mt-3"
      tabindex="-1"
      id="sidebar"
    >
      <div class="offcanvas-body p-0">
        <nav class="navbar-light">
          <ul class="navbar-nav">
            <!-- Dashboard -->
            <li>
              <a href="dashboardAdmin.php" class="nav-link px-3 active mt-4">
                <span class="me-2"><i class="bi bi-speedometer2"></i></span>
                <span>Dashboard</span>
              </a>
            </li>
            <!-- end of Dashboard -->
            <li class="my-4"><hr class="dropdown-divider bg-light" /></li>
            <li>
              <div class="small fw-bold text-uppercase px-3 mb-3">
                Manage Data
              </div>
            </li>
            <li>
            <!-- Kendaraan -->
            <li>
            <a class="nav-link px-3 sidebar-link" data-bs-toggle="collapse" href="#kendaraanLayouts">
                <span class="me-2"><i class="bi bi-car-front-fill"></i></span>
                <span>Kendaraan</span>
                <span class="ms-auto">
                <span class="right-icon">
                    <i class="bi bi-chevron-down"></i>
                </span>
                </span>
            </a>
            <div class="collapse" id="kendaraanLayouts">
                <ul class="navbar-nav ps-3">
                <li>
                    <a href="adminAddVehicle.php" class="nav-link px-3 custom-bg" >
                    <span class="me-2"></span>
                    <span>Add</span>
                    </a>
                </li>
                <li>
                    <a href="adminViewVehicle.php" class="nav-link px-3 custom-bg">
                    <span class="me-2"></span>
                    <span>View</span>
                    </a>
                </li>
                <li>
                    <a href="adminManageVehicle.php" class="nav-link px-3 custom-bg">
                    <span class="me-2"></span>
                    <span>Manage</span>
                    </a>
                </li>
                </ul>
            </div>
            </li>
            <!-- end of kendaraan -->

            <!-- Karyawan -->
            <li>
            <a class="nav-link px-3 sidebar-link" data-bs-toggle="collapse" href="#karyawanLayouts">
                <span class="me-2"><i class="bi bi-person-vcard-fill"></i></span>
                <span>Karyawan</span>
                <span class="ms-auto">
                <span class="right-icon">
                    <i class="bi bi-chevron-down"></i>
                </span>
                </span>
            </a>
            <div class="collapse" id="karyawanLayouts">
                <ul class="navbar-nav ps-3">
                <li>
                    <a href="adminAddKaryawan.php" class="nav-link px-3 custom-bg">
                    <span class="me-2"></span>
                    <span>Add</span>
                    </a>
                </li>
                <li>
                    <a href="adminViewKaryawan.php" class="nav-link px-3 custom-bg">
                    <span class="me-2"></span>
                    <span>View</span>
                    </a>
                </li>
                <li>
                    <a href="adminManageKaryawan.php" class="nav-link px-3 custom-bg">
                    <span class="me-2"></span>
                    <span>Manage</span>
                    </a>
                </li>
                </ul>
            </div>
            </li>
            <!-- end of Karyawan -->

            <!-- Jadwal -->
            <li>
            <a class="nav-link px-3 sidebar-link" data-bs-toggle="collapse" href="#jadwalLayouts">
                <span class="me-2"><i class="bi bi-calendar-check-fill"></i></span>
                <span>Jadwal</span>
                <span class="ms-auto">
                <span class="right-icon">
                    <i class="bi bi-chevron-down"></i>
                </span>
                </span>
            </a>
            <div class="collapse" id="jadwalLayouts">
                <ul class="navbar-nav ps-3">
                <li>
                    <a href="adminAddJadwal.php" class="nav-link px-3 custom-bg">
                    <span class="me-2"></span>
                    <span>Add</span>
                    </a>
                </li>
                <li>
                    <a href="adminViewJadwal.php" class="nav-link px-3 custom-bg">
                    <span class="me-2"></span>
                    <span>View</span>
                    </a>
                </li>
                <li>
                    <a href="adminManageJadwal.php" class="nav-link px-3 custom-bg">
                    <span class="me-2"></span>
                    <span>Manage</span>
                    </a>
                </li>
                </ul>
            </div>
            </li>
            <!-- end of Jadwal -->

            <li class="my-4"><hr class="dropdown-divider bg-light" /></li>
            <li>
              <div class="text-muted small fw-bold text-uppercase px-3 mb-3">
                Check
              </div>
            </li>
            <li>

            <!-- Kehadiran -->
            <li>
              <a href="adminKehadiran.php" class="nav-link px-3 active">
                <span class="me-2"><i class="bi bi-card-checklist"></i></span>
                <span>Kehadiran</span>
              </a>
            </li>
            <!-- end of Kehadiran -->

            <!-- Bahan Bakar -->
            <li>
              <a href="adminBahanBakar.php" class="nav-link px-3 active">
                <span class="me-2"><i class="bi bi-fuel-pump-fill"></i></span>
                <span>Bahan Bakar</span>
              </a>
            </li>
            <!-- end of Bahan Bakar -->

          </ul>
        </nav>
      </div>
    </div>
    <!-- offcanvas -->
    <main class="mt-5 pt-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="breadcrumb mt-4">
              <span class="breadcrumb-item active">Bahan Bakar</span>
              <span class="breadcrumb-item">View</span>
            </div>
            <div class="vehicle-header">
              <h3>Table Information</h3>
            </div>
          </div>
        </div>
        <div class="row">
          <!-- DataTables Example -->
          <div class="table-responsive mt-4">
            <table class="table align-middle table-bordered table-hover">
              <thead>
                <tr>
                  <th><center>No</center></th>
                  <th>Nama</th>
                  <th>Plat</th>
                  <th>Jenis</th>
                  <th>Total Biaya Pengisian</th>
                  <th>Tanggal Transaksi</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              <?php
                  while($result = mysqli_fetch_assoc($sql)){
              ?>
                <tr>
                  <td><center><?php echo ++$no?>.</center></td>
                  <td><?php echo $result['nama']?></td>
                  <td><?php echo $result['plat']?></td>
                  <td><?php echo $result['jenis']?></td>
                  <td><?php echo $result['total_biaya']?></td>
                  <td><?php echo $result['tanggal_transaksi']?></td>
                  <td>
                    <a href="adminViewBahanBakar.php?ubah=<?php echo $result['fuel_filling_id']?>" type="button" class="btn btn-success btn-sm">View</a>
                    
                  </td>
                </tr>
                <?php
                  }
                ?>
              </tbody>
            </table>
          </div>
          <!-- /.container-fluid -->
        </div>
      </div>
    </main>
    <footer class="footer mt-auto py-3 fixed-bottom">
        <div class="container">
          <span class="footer-text">
            &copy; <?php echo date('Y');?> Armada Booking System | Crafted With <i class="bi bi-heart-fill"></i> By ADSI KELOMPOK 8
          </span>
        </div>
    </footer>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.0.2/dist/chart.min.js"></script>
    <script src="js/jquery-3.5.1.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap5.min.js"></script>
    <script src="js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.all.min.js"></script>
</body>
</html>

<?php
$mysqli->close();
?>
