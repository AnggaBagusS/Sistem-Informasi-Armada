<?php
include "SESSION-Login/koneksi.php";

if (isset($_POST['aksi'])) {
    $aksi = $_POST['aksi'];
    $nama = $_POST['nama'];
    $plat = $_POST['plat'];
    $jenis = $_POST['jenis'];
    $tanggal_absen = $_POST['tanggal_absen'];
    $waktu_kehadiran = $_POST['waktu_kehadiran'];
    $dir = "SESSION-Login/uploads/absensi/";

    if ($aksi == "add") {
        $image = $_FILES['bukti_kehadiran']['name'];
        $tmpFile = $_FILES['bukti_kehadiran']['tmp_name'];
        move_uploaded_file($tmpFile, $dir . $image);

        // Insert data ke tabel vehicle
        $query_vehicle = "INSERT INTO vehicle (jenis, plat) VALUES ('$jenis', '$plat')";
        if (mysqli_query($mysqli, $query_vehicle)) {
            $vehicle_id = mysqli_insert_id($mysqli);
            $query_attendance = "INSERT INTO attendance (driver_id, vehicle_id, tanggal_absen, waktu_kehadiran, bukti_kehadiran) VALUES ((SELECT driver_id FROM driver WHERE nama='$nama'), '$vehicle_id', '$tanggal_absen', '$waktu_kehadiran', '$image')";
            if (mysqli_query($mysqli, $query_attendance)) {
                header('Location: adminKehadiran.php?status=success');
                exit();
            } else {
                echo "Error: " . mysqli_error($mysqli);
            }
        } else {
            echo "Error: " . mysqli_error($mysqli);
        }
    } else if ($aksi == "edit") {
        $attendance_id = $_POST['attendance_id'];
        $query_update_vehicle = "UPDATE vehicle SET jenis='$jenis', plat='$plat' WHERE id=(SELECT vehicle_id FROM attendance WHERE attendance_id='$attendance_id')";
        if (mysqli_query($mysqli, $query_update_vehicle)) {
            if ($_FILES['bukti_kehadiran']['name']) {
                // Handle new image upload
                $image = $_FILES['bukti_kehadiran']['name'];
                $tmpFile = $_FILES['bukti_kehadiran']['tmp_name'];
                move_uploaded_file($tmpFile, $dir . $image);

                // Get old image path
                $query_old_image = "SELECT bukti_kehadiran FROM attendance WHERE attendance_id = '$attendance_id'";
                $result_old_image = mysqli_query($mysqli, $query_old_image);
                if ($result_old_image && mysqli_num_rows($result_old_image) > 0) {
                    $row = mysqli_fetch_assoc($result_old_image);
                    $old_image_path = $row['bukti_kehadiran'];
                    if (file_exists($dir . $old_image_path)) {
                        unlink($dir . $old_image_path);
                    }
                }

                // Update new image path
                $query_update_image = "UPDATE attendance SET bukti_kehadiran='$image' WHERE attendance_id='$attendance_id'";
                if (!mysqli_query($mysqli, $query_update_image)) {
                    echo "Error updating image: " . mysqli_error($mysqli);
                }
            }

            $query_update_attendance = "UPDATE attendance SET tanggal_absen='$tanggal_absen', waktu_kehadiran='$waktu_kehadiran' WHERE attendance_id='$attendance_id'";
            if (mysqli_query($mysqli, $query_update_attendance)) {
                header('Location: adminKehadiran.php?status=edit-success');
                exit();
            } else {
                echo "Error: " . mysqli_error($mysqli);
            }
        } else {
            echo "Error: " . mysqli_error($mysqli);
        }
    }
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    $query_select_image = "SELECT bukti_kehadiran FROM attendance WHERE attendance_id = '$id'";
    $result_select_image = mysqli_query($mysqli, $query_select_image);
    if ($result_select_image && mysqli_num_rows($result_select_image) > 0) {
        $row = mysqli_fetch_assoc($result_select_image);
        $image_path = $row['bukti_kehadiran'];
        if (file_exists($dir . $image_path)) {
            unlink($dir . $image_path);
        }

        $query_delete_attendance = "DELETE FROM attendance WHERE attendance_id = '$id'";
        if (mysqli_query($mysqli, $query_delete_attendance)) {
            header('Location: adminKehadiran.php?status=delete-success');
            exit();
        } else {
            echo "Error: " . mysqli_error($mysqli);
        }
    } else {
        echo "Data tidak ditemukan atau ada kesalahan dalam pengambilan data gambar.";
    }
}

mysqli_close($mysqli);
?>
